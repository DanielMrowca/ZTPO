#! python3
# -*- coding: utf-8 -*-

price_list = {
    'HouseBlend': 3.60,
    'DarkRoast': 3.75,
    'Decaf': 4.00,
    'Espresso': 7.50,
    'SteamedMilk': 0.40,
    'Mocha': 0.80,
    'Soy': 0.60,
    'Whip': 0.40,
    'BlackTea': 2.40,
    'GreenTea': 2.80,
    'Cinnamon': 0.20,
    'Honey': 0.80,
    'Sugar': 0.05,
}